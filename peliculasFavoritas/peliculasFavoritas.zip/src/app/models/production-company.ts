export interface ProductionCompany {
    id: number;
    logo_path?: any;
    name: string;
    origin_country: string;
}