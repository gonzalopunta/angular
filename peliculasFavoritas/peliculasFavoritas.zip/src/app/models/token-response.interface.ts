export interface TokenResponse {
    success: boolean;
    expires_at: string;
    request_token: string;
}