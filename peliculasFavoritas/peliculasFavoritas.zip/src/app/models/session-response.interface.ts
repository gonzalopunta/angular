export interface SessionResponse {
    success: boolean;
    session_id: string;
}